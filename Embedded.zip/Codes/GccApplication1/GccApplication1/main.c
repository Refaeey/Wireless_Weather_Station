/*
 * GccApplication1.c
 *
 * Created: 2025-06-13 6:50:03 PM
 * Author : Mohamed Elrefaeey
 */ 

#include <avr/io.h>


int main(void)
{
    /* Replace with your application code */
    while (1) 
    {
    }
}

