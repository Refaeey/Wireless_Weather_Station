/*
 * GccApplication1.c
 *
 * Created: 2025-05-14 8:12:01 PM
 * Author : Mohamed Elrefaeey
 */ 
#define F_CPU 1000000
#include <avr/io.h>
#include <stdio.h>
#include <util/delay.h>
#include <stdbool.h>

#define DHT_PORT PORTA
#define DHT_DDR  DDRA
#define DHT_PIN  PINA
#define DHT_INPUTPIN PA0

uint8_t dht_data[5];

void lcdCommand(uint8_t cmnd){
	PORTC = cmnd; //send cmnd to data port
	PORTD &= ~(1<<PD0); // RS= 0 for command
	PORTD &= ~(1<<PD1); // RW= 0 for write
	PORTD |= (1<<PD2);  // E: Put PORTD bit 2 HIGH
	_delay_ms(1);       // wait to make enable wide
	PORTD &= ~(1<<PD2); // Put PORTD bit 2 LOW
	_delay_ms(3);       // small delay
}

void lcdData(uint8_t data){
	PORTC = data;      // send data to data port
	PORTD |= (1<<PD0); // RS = 1 for data
	PORTD &= ~(1<<PD1);// RW = 0 for write
	PORTD |= (1<<PD2); // E: Put PORTD bit 2 HIGH
	_delay_ms(1);      // wait to make enable wide
	PORTD &= ~(1<<PD2);// Put PORTD bit 2 LOW
	_delay_ms(3);      // small delay
}

void lcdClear(void){
	lcdCommand(0x01); // Clear display command
	_delay_ms(2);     // Wait for display to clear
}

void lcdSetCursor(uint8_t row, uint8_t col){
	uint8_t position;
	if(row == 0){
		position = 0x80 + col; // First row starts at 0x80
	}else{
		position = 0xC0 + col; // Second row starts at 0xC0
	}
	lcdCommand(position);
}

void Request() {
	// Set as output
	DHT_DDR |= (1<<DHT_INPUTPIN);
	// Pull low for 20ms
	DHT_PORT &= ~(1<<DHT_INPUTPIN);
	_delay_ms(20);
	// Pull high
	DHT_PORT |= (1<<DHT_INPUTPIN);
	_delay_us(30);
}

void Response() {
	// Set as input
	DHT_DDR &= ~(1<<DHT_INPUTPIN);
	while(DHT_PIN & (1<<DHT_INPUTPIN)); // Wait for low
	while(!(DHT_PIN & (1<<DHT_INPUTPIN))); // Wait for high
	while(DHT_PIN & (1<<DHT_INPUTPIN)); // Wait for low
}

uint8_t Receive_data() {
	uint8_t data = 0;
	for(int i=0; i<8; i++) {
		while(!(DHT_PIN & (1<<DHT_INPUTPIN))); // Wait for high
		_delay_us(30);
		if(DHT_PIN & (1<<DHT_INPUTPIN)){
			data = (data<<1) | 1;
		}
		else{
			data = (data<<1);
		}
		while(DHT_PIN & (1<<DHT_INPUTPIN)); // Wait for low
	}
	return data;
}

bool DHT11_Read() {
	Request();
	Response();
	dht_data[0] = Receive_data();  // Humidity integer
	dht_data[1] = Receive_data();  // Humidity decimal
	dht_data[2] = Receive_data();  // Temperature integer
	dht_data[3] = Receive_data();  // Temperature decimal
	dht_data[4] = Receive_data();  // Checksum
	uint8_t checksum = dht_data[0] + dht_data[2];
	return (checksum == dht_data[4]);
}

void LCDinitialize(){
	DDRC = 0xFF; // Data PORT
	DDRD = 0xFF; // Command PORT
	_delay_ms(20); // Wait for LCD to power up
	
	lcdCommand(0x38); // 8-bit mode, 2 lines, 5x7 dots
	lcdCommand(0x0C); // Display on, cursor off
	lcdCommand(0x01); // Clear display
	_delay_ms(2);
	lcdCommand(0x06); // Increment cursor, no shift
}

void lcd_print(char *str){
	// Send string as pointer of char
	unsigned int i = 0;
	while(str[i] != 0){
		lcdData(str[i]);
		i++;
	}
}

int main(void)
{
	char buffer[16];
	uint8_t prev_temp = 0;
	uint8_t prev_hum = 0;
	
	LCDinitialize();
	
	while(1) {
		bool valid_reading = DHT11_Read();
		
		if(valid_reading) {
			uint8_t temp = dht_data[2];
			uint8_t hum = dht_data[0];
			
			// Only update the display if the values have changed
			if(temp != prev_temp || hum != prev_hum) {
				prev_temp = temp;
				prev_hum = hum;
				
				// Position cursor at beginning of first line
				lcdSetCursor(0, 0);
				
				// Format and print the data
				sprintf(buffer, "T:%d C  H:%d%%  ", temp, hum);
				lcd_print(buffer);
			}
		}
		
		// Wait before next reading
		_delay_ms(1000);
	}
}